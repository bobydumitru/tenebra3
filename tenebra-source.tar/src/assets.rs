use sha2::{Digest, Sha256};
use curve25519_dalek::{constants::RISTRETTO_BASEPOINT_POINT, ristretto::CompressedRistretto, scalar::Scalar};
use sha2::Sha512;
use std::collections::BTreeMap;

pub type AssetId = [u8; 32];

pub const TNB_ASSET_ID: AssetId = [0; 32];

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct AssetDefinition {
    pub id: AssetId,
    pub issuer: [u8; 32],
    pub name: String,
    pub symbol: String,
    pub decimals: u8,
    pub max_supply: u64,
    pub minted: u64,
}

impl AssetDefinition {
    pub fn derive_id(issuer: &[u8; 32], nonce: u64) -> AssetId {
        let mut hash = Sha256::new();
        hash.update(b"TENEBRA:asset:v1");
        hash.update(issuer);
        hash.update(nonce.to_le_bytes());
        hash.finalize().into()
    }

    pub fn new(
        issuer: [u8; 32],
        nonce: u64,
        name: String,
        symbol: String,
        decimals: u8,
        max_supply: u64,
        initial_supply: u64,
    ) -> Result<Self, &'static str> {
        if name.is_empty() || name.len() > 64 || symbol.is_empty() || symbol.len() > 16 {
            return Err("invalid asset metadata");
        }
        if !name.is_ascii() || !symbol.is_ascii() || decimals > 18 || max_supply == 0 {
            return Err("invalid asset metadata");
        }
        if initial_supply > max_supply {
            return Err("initial supply exceeds max supply");
        }
        Ok(Self {
            id: Self::derive_id(&issuer, nonce),
            issuer,
            name,
            symbol,
            decimals,
            max_supply,
            minted: initial_supply,
        })
    }

    pub fn remaining_supply(&self) -> u64 {
        self.max_supply - self.minted
    }

    pub fn mint(&mut self, amount: u64) -> Result<(), &'static str> {
        self.minted = self.minted.checked_add(amount).ok_or("supply overflow")?;
        if self.minted > self.max_supply {
            return Err("asset max supply exceeded");
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct AssetRegistry {
    assets: BTreeMap<AssetId, AssetDefinition>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum AssetTransaction {
    Create {
        issuer: [u8; 32],
        nonce: u64,
        name: String,
        symbol: String,
        decimals: u8,
        max_supply: u64,
        initial_supply: u64,
    },
    Mint {
        asset_id: AssetId,
        issuer: [u8; 32],
        amount: u64,
    },
    Transfer {
        asset_id: AssetId,
        from: [u8; 32],
        to: [u8; 32],
        amount: u64,
    },
}

impl AssetTransaction {
    pub fn decode(bytes: &[u8]) -> Result<Self, &'static str> {
        const PREFIX: &[u8] = b"TSC-1:asset-tx:v2";
        if bytes.len() <= PREFIX.len() || &bytes[..PREFIX.len()] != PREFIX { return Err("wrong asset transaction format"); }
        let kind = bytes[PREFIX.len()];
        let mut cursor = PREFIX.len() + 1;
        let take = |cursor: &mut usize, count: usize| -> Result<&[u8], &'static str> {
            if *cursor + count > bytes.len() { return Err("truncated asset transaction"); }
            let slice = &bytes[*cursor..*cursor + count]; *cursor += count; Ok(slice)
        };
        let array = |cursor: &mut usize| -> Result<[u8; 32], &'static str> { take(cursor, 32)?.try_into().map_err(|_| "invalid asset field") };
        let u64_at = |cursor: &mut usize| -> Result<u64, &'static str> { Ok(u64::from_le_bytes(take(cursor, 8)?.try_into().map_err(|_| "invalid asset integer")?)) };
        let tx = match kind {
            0 => {
                let issuer = array(&mut cursor)?; let nonce = u64_at(&mut cursor)?;
                let name_len = take(&mut cursor, 1)?[0] as usize; let name = String::from_utf8(take(&mut cursor, name_len)?.to_vec()).map_err(|_| "invalid asset name")?;
                let symbol_len = take(&mut cursor, 1)?[0] as usize; let symbol = String::from_utf8(take(&mut cursor, symbol_len)?.to_vec()).map_err(|_| "invalid asset symbol")?;
                let decimals = take(&mut cursor, 1)?[0]; let max_supply = u64_at(&mut cursor)?; let initial_supply = u64_at(&mut cursor)?;
                Self::Create { issuer, nonce, name, symbol, decimals, max_supply, initial_supply }
            }
            1 => Self::Mint { asset_id: array(&mut cursor)?, issuer: array(&mut cursor)?, amount: u64_at(&mut cursor)? },
            2 => Self::Transfer { asset_id: array(&mut cursor)?, from: array(&mut cursor)?, to: array(&mut cursor)?, amount: u64_at(&mut cursor)? },
            _ => return Err("unknown asset transaction kind"),
        };
        if cursor != bytes.len() { return Err("trailing asset transaction bytes"); }
        Ok(tx)
    }

    pub fn encode(&self) -> Result<Vec<u8>, &'static str> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(b"TSC-1:asset-tx:v2");
        match self {
            Self::Create { issuer, nonce, name, symbol, decimals, max_supply, initial_supply } => {
                if name.len() > 64 || symbol.len() > 16 || !name.is_ascii() || !symbol.is_ascii() { return Err("invalid asset metadata"); }
                bytes.push(0);
                bytes.extend_from_slice(issuer);
                bytes.extend_from_slice(&nonce.to_le_bytes());
                bytes.push(name.len() as u8); bytes.extend_from_slice(name.as_bytes());
                bytes.push(symbol.len() as u8); bytes.extend_from_slice(symbol.as_bytes());
                bytes.push(*decimals);
                bytes.extend_from_slice(&max_supply.to_le_bytes());
                bytes.extend_from_slice(&initial_supply.to_le_bytes());
            }
            Self::Mint { asset_id, issuer, amount } => {
                bytes.push(1); bytes.extend_from_slice(asset_id); bytes.extend_from_slice(issuer); bytes.extend_from_slice(&amount.to_le_bytes());
            }
            Self::Transfer { asset_id, from, to, amount } => {
                bytes.push(2); bytes.extend_from_slice(asset_id); bytes.extend_from_slice(from); bytes.extend_from_slice(to); bytes.extend_from_slice(&amount.to_le_bytes());
            }
        }
        Ok(bytes)
    }

    pub fn txid(&self) -> Result<AssetId, &'static str> {
        Ok(Sha256::digest(self.encode()?).into())
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SignedAssetTransaction {
    pub transaction: AssetTransaction,
    pub issuer_public: [u8; 32],
    pub signature: [u8; 64],
}

fn challenge(public: &[u8; 32], message: &[u8], commitment: &[u8; 32]) -> Scalar {
    let mut hash = Sha512::new();
    hash.update(b"TENEBRA:asset-issuer:v1");
    hash.update(public); hash.update(message); hash.update(commitment);
    Scalar::from_hash(hash)
}

pub fn sign_issuer(transaction: &AssetTransaction, secret: Scalar, nonce_wide: &[u8; 64]) -> Result<SignedAssetTransaction, &'static str> {
    let public = (secret * RISTRETTO_BASEPOINT_POINT).compress().to_bytes();
    let message = transaction.encode()?;
    let nonce = Scalar::from_bytes_mod_order_wide(nonce_wide);
    let commitment = (nonce * RISTRETTO_BASEPOINT_POINT).compress().to_bytes();
    let response = nonce + challenge(&public, &message, &commitment) * secret;
    Ok(SignedAssetTransaction { transaction: transaction.clone(), issuer_public: public, signature: [commitment, response.to_bytes()].concat().try_into().map_err(|_| "signature encoding failed")? })
}

impl SignedAssetTransaction {
    pub fn verify(&self) -> Result<(), &'static str> {
        let message = self.transaction.encode()?;
        let commitment = CompressedRistretto(self.signature[..32].try_into().map_err(|_| "invalid signature")?).decompress().ok_or("invalid issuer commitment")?;
        let response = Scalar::from_canonical_bytes(self.signature[32..].try_into().map_err(|_| "invalid signature")?).into_option().ok_or("invalid issuer response")?;
        let public = CompressedRistretto(self.issuer_public).decompress().ok_or("invalid issuer key")?;
        if response * RISTRETTO_BASEPOINT_POINT != commitment + challenge(&self.issuer_public, &message, &self.signature[..32].try_into().map_err(|_| "invalid signature")?) * public { return Err("invalid issuer signature"); }
        match &self.transaction {
            AssetTransaction::Create { issuer, .. } | AssetTransaction::Mint { issuer, .. } if issuer != &self.issuer_public => Err("issuer key mismatch"),
            AssetTransaction::Transfer { from, .. } if from != &self.issuer_public => Err("transfer key mismatch"),
            _ => Ok(()),
        }
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct AssetLedger {
    pub registry: AssetRegistry,
    balances: BTreeMap<(AssetId, [u8; 32]), u64>,
}

impl AssetLedger {
    pub fn balance(&self, asset_id: &AssetId, owner: &[u8; 32]) -> u64 {
        self.balances.get(&(*asset_id, *owner)).copied().unwrap_or(0)
    }

    pub fn apply(&mut self, transaction: AssetTransaction) -> Result<AssetId, &'static str> {
        match transaction {
            AssetTransaction::Create { issuer, nonce, name, symbol, decimals, max_supply, initial_supply } => {
                let asset = AssetDefinition::new(issuer, nonce, name, symbol, decimals, max_supply, initial_supply)?;
                let id = self.registry.register(asset)?;
                if initial_supply > 0 {
                    self.credit(id, &issuer, initial_supply)?;
                }
                Ok(id)
            }
            AssetTransaction::Mint { asset_id, issuer, amount } => {
                let asset = self.registry.get(&asset_id).ok_or("unknown asset")?;
                if asset.issuer != issuer {
                    return Err("mint issuer mismatch");
                }
                self.registry.mint(&asset_id, amount)?;
                self.credit(asset_id, &issuer, amount)?;
                Ok(asset_id)
            }
            AssetTransaction::Transfer { asset_id, from, to, amount } => {
                if amount == 0 || from == to {
                    return Err("invalid asset transfer");
                }
                let current = self.balance(&asset_id, &from);
                if current < amount {
                    return Err("insufficient asset balance");
                }
                self.debit(asset_id, &from, amount)?;
                self.credit(asset_id, &to, amount)?;
                Ok(asset_id)
            }
        }
    }

    pub fn transfer(&mut self, asset_id: AssetId, from: &[u8; 32], to: &[u8; 32], amount: u128) -> Result<(), &'static str> {
        let amount = u64::try_from(amount).map_err(|_| "asset amount exceeds u64")?;
        self.apply(AssetTransaction::Transfer { asset_id, from: *from, to: *to, amount })?;
        Ok(())
    }

    fn credit(&mut self, asset_id: AssetId, owner: &[u8; 32], amount: u64) -> Result<(), &'static str> {
        let entry = self.balances.entry((asset_id, *owner)).or_default();
        *entry = entry.checked_add(amount).ok_or("balance overflow")?;
        Ok(())
    }

    fn debit(&mut self, asset_id: AssetId, owner: &[u8; 32], amount: u64) -> Result<(), &'static str> {
        let entry = self.balances.get_mut(&(asset_id, *owner)).ok_or("insufficient asset balance")?;
        *entry = entry.checked_sub(amount).ok_or("insufficient asset balance")?;
        Ok(())
    }
}

impl AssetRegistry {
    pub fn register(&mut self, asset: AssetDefinition) -> Result<AssetId, &'static str> {
        if asset.id == TNB_ASSET_ID || self.assets.contains_key(&asset.id) {
            return Err("asset already registered");
        }
        self.assets.insert(asset.id, asset.clone());
        Ok(asset.id)
    }

    pub fn get(&self, id: &AssetId) -> Option<&AssetDefinition> {
        if *id == TNB_ASSET_ID {
            return None;
        }
        self.assets.get(id)
    }

    pub fn mint(&mut self, id: &AssetId, amount: u64) -> Result<(), &'static str> {
        self.assets.get_mut(id).ok_or("unknown asset")?.mint(amount)
    }

    pub fn iter(&self) -> impl Iterator<Item = &AssetDefinition> {
        self.assets.values()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn asset_id_is_deterministic_and_supply_is_bounded() {
        let issuer = [7u8; 32];
        let mut asset = AssetDefinition::new(
            issuer,
            1,
            "Project Coin".into(),
            "PRJ".into(),
            6,
            1_000,
            250,
        )
        .unwrap();
        assert_eq!(asset.id, AssetDefinition::derive_id(&issuer, 1));
        assert_eq!(asset.remaining_supply(), 750);
        assert!(asset.mint(750).is_ok());
        assert_eq!(asset.remaining_supply(), 0);
        assert_eq!(asset.mint(1), Err("asset max supply exceeded"));
    }

    #[test]
    fn registry_rejects_duplicate_ids() {
        let asset = AssetDefinition::new([1u8; 32], 4, "Coin".into(), "COIN".into(), 8, 10, 0).unwrap();
        let mut registry = AssetRegistry::default();
        assert!(registry.register(asset.clone()).is_ok());
        assert_eq!(registry.register(asset), Err("asset already registered"));
    }

    #[test]
    fn ledger_creates_mints_and_transfers_assets_without_unbounded_issuance() {
        let issuer = [1u8; 32];
        let receiver = [2u8; 32];
        let mut ledger = AssetLedger::default();
        let id = ledger.apply(AssetTransaction::Create {
            issuer,
            nonce: 9,
            name: "Project Coin".into(),
            symbol: "PRJ".into(),
            decimals: 6,
            max_supply: 1_000,
            initial_supply: 100,
        }).unwrap();
        assert_eq!(ledger.balance(&id, &issuer), 100);
        ledger.apply(AssetTransaction::Mint { asset_id: id, issuer, amount: 400 }).unwrap();
        assert_eq!(ledger.balance(&id, &issuer), 500);
        ledger.apply(AssetTransaction::Transfer { asset_id: id, from: issuer, to: receiver, amount: 125 }).unwrap();
        assert_eq!(ledger.balance(&id, &issuer), 375);
        assert_eq!(ledger.balance(&id, &receiver), 125);
        assert_eq!(ledger.apply(AssetTransaction::Mint { asset_id: id, issuer, amount: 501 }), Err("asset max supply exceeded"));
        assert_eq!(ledger.apply(AssetTransaction::Mint { asset_id: id, issuer: [3u8; 32], amount: 1 }), Err("mint issuer mismatch"));
    }

    #[test]
    fn asset_transactions_have_domain_separated_ids() {
        let tx = AssetTransaction::Mint { asset_id: [4u8; 32], issuer: [5u8; 32], amount: 7 };
        let encoded = tx.encode().unwrap();
        assert!(encoded.starts_with(b"TSC-1:asset-tx:v2"));
        let expected: [u8; 32] = Sha256::digest(encoded).into();
        assert_eq!(tx.txid().unwrap(), expected);
    }

    #[test]
    fn issuer_signature_is_required_and_binds_operation() {
        let secret = Scalar::from(11u64);
        let transaction = AssetTransaction::Create { issuer: (secret * RISTRETTO_BASEPOINT_POINT).compress().to_bytes(), nonce: 1, name: "Coin".into(), symbol: "COIN".into(), decimals: 8, max_supply: 100, initial_supply: 1 };
        let signed = sign_issuer(&transaction, secret, &[8u8; 64]).unwrap();
        assert!(signed.verify().is_ok());
        let mut changed = signed.clone();
        if let AssetTransaction::Create { ref mut max_supply, .. } = changed.transaction { *max_supply = 101; }
        assert_eq!(changed.verify(), Err("invalid issuer signature"));
    }
}

//! Offline one-input transaction construction for the isolated v3 devnet.

use crate::assets::TNB_ASSET_ID;
use crate::tsc1_chain_v2::Hash;
use crate::tsc1_chain_v3::ChainV3;
use crate::tsc1_funded_output::create_funded_output_with_blinding;
use crate::tsc1_private_amounts::random_blinding;
use crate::tsc1_tx_v2::{
    AUTHORIZATION_BYTES, AuthorizationProof, NETWORK_ID, RING_SIZE, RingInput, Transaction,
    key_image_for_secret,
};
use crate::{Address, WalletSecrets};
use bulletproofs::PedersenGens;
use curve25519_dalek::scalar::Scalar;

fn random_index(upper: usize) -> Result<usize, &'static str> {
    let upper = upper as u64;
    let zone = u64::MAX - u64::MAX % upper;
    loop {
        let mut bytes = [0u8; 8];
        getrandom::getrandom(&mut bytes).map_err(|_| "OS randomness unavailable")?;
        let value = u64::from_le_bytes(bytes);
        if value < zone {
            return Ok((value % upper) as usize);
        }
    }
}

fn choose_ring(mut eligible: Vec<Hash>, owned: Hash) -> Result<[Hash; RING_SIZE], &'static str> {
    eligible.retain(|id| *id != owned);
    if eligible.len() < RING_SIZE - 1 {
        return Err("not enough mature outputs for a private ring");
    }
    for end in (1..eligible.len()).rev() {
        let index = random_index(end + 1)?;
        eligible.swap(end, index);
    }
    let mut ring: Vec<_> = eligible.into_iter().take(RING_SIZE - 1).collect();
    ring.push(owned);
    ring.sort();
    ring.try_into().map_err(|_| "invalid ring size")
}

pub fn create_signed_transfer(
    chain: &ChainV3,
    wallet: &WalletSecrets,
    recipient: &Address,
    amount_nox: u64,
    fee_nox: u64,
) -> Result<Transaction, &'static str> {
    if amount_nox == 0 || fee_nox == 0 {
        return Err("amount and fee must be positive");
    }
    let required = amount_nox
        .checked_add(fee_nox)
        .ok_or("amount plus fee overflow")?;
    let height = chain.height().checked_add(1).ok_or("height overflow")?;
    let spends = chain.spends();
    let eligible = spends
        .eligible_output_ids(height)
        .into_iter()
        .filter(|id| {
            spends
                .output(id)
                .is_some_and(|output| output.amount.asset_id == TNB_ASSET_ID)
        })
        .collect::<Vec<_>>();
    let mut selected = None;
    for id in &eligible {
        let output = spends.output(id).ok_or("missing spend output")?;
        let index = spends.output_index(id).ok_or("missing output index")?;
        if let Some(recovered) = wallet.scan_funded_output(output, index) {
            let secret =
                Option::<Scalar>::from(Scalar::from_canonical_bytes(recovered.one_time_spend))
                    .ok_or("invalid owned spend key")?;
            if recovered.amount_nox >= required
                && !spends.has_spent_image(&key_image_for_secret(secret))
            {
                selected = Some((*id, recovered, secret));
                break;
            }
        }
    }
    let (owned_id, owned, secret) =
        selected.ok_or("no mature unspent output covers amount and fee")?;
    let ring = choose_ring(eligible, owned_id)?;
    let recipient_blinding = random_blinding().map_err(|_| "OS randomness unavailable")?;
    let mut outputs = vec![create_funded_output_with_blinding(
        recipient,
        0,
        amount_nox,
        recipient_blinding,
    )?];
    let change = owned.amount_nox - required;
    let mut pseudo_blinding = recipient_blinding;
    if change > 0 {
        let change_blinding = random_blinding().map_err(|_| "OS randomness unavailable")?;
        outputs.push(create_funded_output_with_blinding(
            &wallet.address(),
            1,
            change,
            change_blinding,
        )?);
        pseudo_blinding += change_blinding;
    }
    let pseudo_output = PedersenGens::default()
        .commit(Scalar::from(owned.amount_nox), pseudo_blinding)
        .compress()
        .to_bytes();
    let placeholder = AuthorizationProof {
        challenge: Scalar::ONE,
        key_responses: [Scalar::ONE; RING_SIZE],
        amount_responses: [Scalar::ONE; RING_SIZE],
    }
    .encode();
    debug_assert_eq!(placeholder.len(), AUTHORIZATION_BYTES);
    let mut tx = Transaction {
        network_id: NETWORK_ID,
        version: 2,
        expires_at_height: height.checked_add(10).ok_or("expiry overflow")?,
        inputs: vec![RingInput {
            asset_id: TNB_ASSET_ID,
            members: ring,
            key_image: key_image_for_secret(secret),
            pseudo_output,
            authorization: placeholder,
        }],
        outputs,
        fee_nox,
    };
    let statements = tx.ring_statements_with(height, |id| spends.output(id))?;
    let signer = tx.inputs[0]
        .members
        .iter()
        .position(|id| *id == owned_id)
        .ok_or("owned output missing from ring")?;
    tx.inputs[0].authorization = AuthorizationProof::sign(
        &tx.signing_hash()?,
        tx.inputs[0].key_image,
        &statements[0],
        signer,
        secret,
        owned.blinding - pseudo_blinding,
    )?
    .encode();
    let mut staged = spends.clone();
    staged.apply_batch(&[tx.clone()], height)?;
    Ok(tx)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::FOUNDER_ALLOCATION_NOX;
    use crate::tsc1_chain_v2::{Chain, reward_at_height};
    use crate::tsc1_chain_v3::{load_blocks, persist_block};
    use crate::tsc1_funded_output::create_reward_output;
    use crate::tsc1_peer_v3::{
        publish_block, serve_connection_with_genesis, serve_connection_with_peers, submit,
    };
    use crate::tsc1_pending_v3::{load_pending, remove_included};
    use std::net::TcpListener;
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    // Synthetic servers below bypass the production connection entry point.
    // Mirror its candidate handshake here; production validation is unchanged.
    fn candidate_handshake_for_test(mut stream: &std::net::TcpStream) {
        if !crate::network::IS_MAINNET {
            return;
        }
        use std::io::{Read, Write};
        stream
            .set_read_timeout(Some(std::time::Duration::from_secs(10)))
            .unwrap();
        let mut magic = [0; 8];
        let mut genesis = [0; 32];
        stream.read_exact(&mut magic).unwrap();
        stream.read_exact(&mut genesis).unwrap();
        assert_eq!(&magic, crate::network::PEER_MAGIC);
        assert_eq!(
            genesis,
            crate::network::pinned_genesis().unwrap().genesis_hash()
        );
        stream.write_all(crate::network::PEER_MAGIC).unwrap();
    }

    #[test]
    fn signed_transfer_with_change_enters_mined_block() {
        let founder = WalletSecrets::from_seed(&[101; 32]);
        let recipient = WalletSecrets::from_seed(&[102; 32]);
        let genesis = Chain::new(
            create_reward_output(&founder.address(), 0, FOUNDER_ALLOCATION_NOX).unwrap(),
            1,
        )
        .unwrap();
        let genesis_for_server = genesis.clone();
        let mut nonce = [0u8; 8];
        getrandom::getrandom(&mut nonce).unwrap();
        let root =
            std::env::temp_dir().join(format!("tsc1-v3-pending-test-{}", hex::encode(nonce)));
        std::fs::create_dir(&root).unwrap();
        let blocks_dir = root.join("blocks");
        let peer_b_blocks = root.join("peer-b").join("blocks");
        let mut chain = ChainV3::from_genesis(genesis).unwrap();
        for height in 1..=25 {
            let miner = WalletSecrets::from_seed(&[height as u8; 32]);
            let reward =
                create_reward_output(&miner.address(), 0, reward_at_height(height)).unwrap();
            let mut block = chain.next_block(reward, height + 1, Vec::new());
            block.mine().unwrap();
            persist_block(&blocks_dir, &block).unwrap();
            persist_block(&peer_b_blocks, &block).unwrap();
            chain.append(block).unwrap();
        }
        let tx = create_signed_transfer(&chain, &founder, &recipient.address(), 100, 10).unwrap();
        assert_eq!(tx.outputs.len(), 2);
        let peer_b_listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let peer_b_address = peer_b_listener.local_addr().unwrap();
        let peer_b_dir = peer_b_blocks.clone();
        let peer_b_genesis = genesis_for_server.clone();
        let genesis_for_verify = genesis_for_server.clone();
        let (peer_b_ready, peer_b_received) = mpsc::channel();
        let peer_b_server = thread::spawn(move || {
            for request in 0..2 {
                let (stream, _) = peer_b_listener.accept().unwrap();
                candidate_handshake_for_test(&stream);
                serve_connection_with_genesis(stream, &peer_b_dir, peer_b_genesis.clone()).unwrap();
                if request == 0 {
                    peer_b_ready.send(()).unwrap();
                }
            }
        });
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let address = listener.local_addr().unwrap();
        let server_dir = blocks_dir.clone();
        let server = thread::spawn(move || {
            let (stream, _) = listener.accept().unwrap();
            candidate_handshake_for_test(&stream);
            serve_connection_with_peers(
                stream,
                &server_dir,
                genesis_for_server,
                vec![peer_b_address.to_string()],
            )
            .unwrap();
        });
        let txid = submit(&address.to_string(), &tx.encode().unwrap()).unwrap();
        server.join().unwrap();
        peer_b_received
            .recv_timeout(Duration::from_secs(30))
            .unwrap();
        assert_eq!(txid, tx.txid().unwrap());
        let queued = load_pending(&blocks_dir, &chain).unwrap();
        assert_eq!(queued.len(), 1);
        assert_eq!(load_pending(&peer_b_blocks, &chain).unwrap().len(), 1);
        let miner = WalletSecrets::from_seed(&[103; 32]);
        let reward = create_reward_output(&miner.address(), 0, reward_at_height(26)).unwrap();
        let mut block = chain
            .next_block_with_fees(reward, &miner.address(), 27, queued)
            .unwrap();
        block.mine().unwrap();
        let included = block.transactions.clone();
        chain.append(block).unwrap();
        persist_block(&blocks_dir, chain.blocks().last().unwrap()).unwrap();
        remove_included(&blocks_dir, &included).unwrap();
        publish_block(&peer_b_address.to_string(), chain.blocks().last().unwrap()).unwrap();
        peer_b_server.join().unwrap();
        assert_eq!(
            load_blocks(&peer_b_blocks, genesis_for_verify)
                .unwrap()
                .tip_hash(),
            chain.tip_hash(),
        );
        assert_eq!(chain.wallet_balance_nox(&recipient), Ok(100));
        assert_eq!(
            chain.wallet_balance_nox(&founder),
            Ok(FOUNDER_ALLOCATION_NOX - 110)
        );
        assert!(load_pending(&blocks_dir, &chain).unwrap().is_empty());
        for height in 1..=26 {
            std::fs::remove_file(blocks_dir.join(format!("{height:020}.bin"))).unwrap();
            std::fs::remove_file(peer_b_blocks.join(format!("{height:020}.bin"))).unwrap();
        }
        std::fs::remove_dir(blocks_dir).unwrap();
        std::fs::remove_dir(peer_b_blocks).unwrap();
        std::fs::remove_dir(root.join("peer-b").join("pending")).unwrap();
        std::fs::remove_dir(root.join("peer-b")).unwrap();
        std::fs::remove_dir(root.join("pending")).unwrap();
        std::fs::remove_dir(root).unwrap();
    }
}

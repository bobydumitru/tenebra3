//! Aggregate native-fee split for one block.

pub fn split_block_fees(total_fee_nox: u64) -> (u64, u64) {
    let treasury_nox = total_fee_nox / 10;
    (total_fee_nox - treasury_nox, treasury_nox)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn split_preserves_all_nox_even_at_u64_max() {
        for amount in [0, 1, 9, 10, 99, 100, u64::MAX] {
            let (miner, treasury) = split_block_fees(amount);
            assert_eq!(miner.checked_add(treasury), Some(amount));
            assert_eq!(treasury, amount / 10);
        }
    }
}

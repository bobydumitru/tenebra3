//! TSC-1 private-amount prototype. Not yet connected to chain consensus.
//! Every output needs a valid range proof AND a balanced transaction.

use bulletproofs::{BulletproofGens, PedersenGens, RangeProof};
use curve25519_dalek::ristretto::{CompressedRistretto, RistrettoPoint};
use curve25519_dalek::scalar::Scalar;
use merlin::Transcript;
use std::sync::LazyLock;

pub const TNB_ASSET_ID: [u8; 32] = [0; 32];
const PROOF_BITS: usize = 64;
// Public deterministic generators are immutable. Each proof still gets a fresh transcript.
static RANGE_GENERATORS: LazyLock<BulletproofGens> =
    LazyLock::new(|| BulletproofGens::new(PROOF_BITS, 1));
static VALUE_GENERATORS: LazyLock<PedersenGens> = LazyLock::new(PedersenGens::default);

#[derive(Clone, Debug)]
pub struct ProvenAmount {
    pub commitment: [u8; 32],
    pub range_proof: Vec<u8>,
}

fn transcript(asset_id: &[u8; 32]) -> Transcript {
    let mut transcript = Transcript::new(b"TSC-1:amount-range:v1");
    transcript.append_message(b"asset-id", asset_id);
    transcript
}

pub fn random_blinding() -> Result<Scalar, getrandom::Error> {
    let mut wide = [0u8; 64];
    getrandom::getrandom(&mut wide)?;
    Ok(Scalar::from_bytes_mod_order_wide(&wide))
}

pub fn prove_amount(
    amount: u64,
    blinding: &Scalar,
    asset_id: &[u8; 32],
) -> Result<ProvenAmount, String> {
    let mut transcript = transcript(asset_id);
    let (proof, commitment) = RangeProof::prove_single(
        &RANGE_GENERATORS,
        &VALUE_GENERATORS,
        &mut transcript,
        amount,
        blinding,
        PROOF_BITS,
    )
    .map_err(|error| format!("range proof creation failed: {error}"))?;
    Ok(ProvenAmount {
        commitment: commitment.to_bytes(),
        range_proof: proof.to_bytes(),
    })
}

pub fn verify_amount(output: &ProvenAmount, asset_id: &[u8; 32]) -> bool {
    let Ok(proof) = RangeProof::from_bytes(&output.range_proof) else {
        return false;
    };
    proof
        .verify_single(
            &RANGE_GENERATORS,
            &VALUE_GENERATORS,
            &mut transcript(asset_id),
            &CompressedRistretto(output.commitment),
            PROOF_BITS,
        )
        .is_ok()
}

/// Verify amount conservation. Only call after verifying every output proof.
/// Inputs and outputs must all belong to the same asset.
pub fn balances(inputs: &[[u8; 32]], outputs: &[[u8; 32]], fee: u64) -> bool {
    let mut input_sum = RistrettoPoint::default();
    let mut output_sum = VALUE_GENERATORS.B * Scalar::from(fee);
    for encoded in inputs {
        let Some(point) = CompressedRistretto(*encoded).decompress() else {
            return false;
        };
        input_sum += point;
    }
    for encoded in outputs {
        let Some(point) = CompressedRistretto(*encoded).decompress() else {
            return false;
        };
        output_sum += point;
    }
    input_sum == output_sum
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_proof_passes_and_wrong_asset_fails() {
        let proof = prove_amount(42, &random_blinding().unwrap(), &TNB_ASSET_ID).unwrap();
        assert!(verify_amount(&proof, &TNB_ASSET_ID));
        assert!(!verify_amount(&proof, &[1; 32]));
    }

    #[test]
    fn changed_commitment_fails() {
        let blind = random_blinding().unwrap();
        let mut proof = prove_amount(42, &blind, &TNB_ASSET_ID).unwrap();
        proof.commitment = prove_amount(43, &blind, &TNB_ASSET_ID).unwrap().commitment;
        assert!(!verify_amount(&proof, &TNB_ASSET_ID));
    }

    #[test]
    fn balanced_transaction_passes_wrong_fee_fails() {
        let input_blind = random_blinding().unwrap();
        let output_blind = random_blinding().unwrap();
        let change_blind = input_blind - output_blind;
        let input = prove_amount(100, &input_blind, &TNB_ASSET_ID).unwrap();
        let output = prove_amount(60, &output_blind, &TNB_ASSET_ID).unwrap();
        let change = prove_amount(39, &change_blind, &TNB_ASSET_ID).unwrap();
        assert!(verify_amount(&output, &TNB_ASSET_ID));
        assert!(verify_amount(&change, &TNB_ASSET_ID));
        assert!(balances(
            &[input.commitment],
            &[output.commitment, change.commitment],
            1
        ));
        assert!(!balances(
            &[input.commitment],
            &[output.commitment, change.commitment],
            2
        ));
    }
}

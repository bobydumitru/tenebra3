//! Isolated transaction-bearing devnet candidate; not a public consensus protocol.

use crate::tsc1_chain_v2::{Block, Chain, Hash, TARGET_BLOCK_SECONDS};
use crate::tsc1_fee::split_block_fees;
use crate::tsc1_funded_output::{FundedOutput, create_public_fee_output, create_reward_output};
use crate::tsc1_spend_state_v2::SpendState;
use crate::tsc1_tx_v2::{Transaction, key_image_for_secret};
use crate::{Address, WalletSecrets, output_from_ephemeral_secret};
use bulletproofs::PedersenGens;
use curve25519_dalek::scalar::Scalar;
use sha2::{Digest, Sha256, Sha512};
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::io::{Cursor, Read};
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

const TAG: &[u8; 10] = if crate::network::IS_MAINNET { b"TNB1BLK001" } else { b"TSC1BLK3F1" };
const BASE_DIFFICULTY_BITS: u8 = 12;
const MAX_DIFFICULTY_BITS: u8 = if crate::network::IS_MAINNET { 120 } else { 24 };
const RETARGET_WINDOW: usize = 16;
const MAX_FUTURE_DRIFT_SECONDS: u64 = 120;
const REWARD_MATURITY_BLOCKS: u64 = 10;
pub const FINALITY_DEPTH: u64 = 10;
// Protocol capacity is not a measured confirmation rate.
pub const MAX_TXS: usize = if crate::network::IS_MAINNET { 9_000 } else { 16 };
const MAX_TX_BYTES: usize = 512 * 1024;
pub(crate) const MAX_BLOCK_BYTES: usize = if crate::network::IS_MAINNET {
    64 * 1024 * 1024
} else { MAX_TXS * MAX_TX_BYTES + 8192 };
const TREASURY_ADDRESS: &str = include_str!("../config/treasury-address.txt");

fn hash_meets_difficulty(hash: &Hash, bits: u8) -> bool {
    if !(BASE_DIFFICULTY_BITS..=MAX_DIFFICULTY_BITS).contains(&bits) {
        return false;
    }
    let full_bytes = (bits / 8) as usize;
    hash[..full_bytes].iter().all(|byte| *byte == 0)
        && (bits.is_multiple_of(8) || hash[full_bytes] >> (8 - bits % 8) == 0)
}

fn treasury_secret(previous_hash: Hash, height: u64) -> Scalar {
    let mut hash = Sha512::new();
    hash.update(b"TSC-1:public-treasury-output:v3b");
    hash.update(previous_hash);
    hash.update(height.to_le_bytes());
    let scalar = Scalar::from_hash(hash);
    if scalar == Scalar::ZERO {
        Scalar::ONE
    } else {
        scalar
    }
}

fn fee_output_id(block_hash: Hash, role: u8) -> Hash {
    let mut hash = Sha256::new();
    hash.update(b"TSC-1:fee-output-id:v3b");
    hash.update(block_hash);
    hash.update([role]);
    hash.finalize().into()
}

fn valid_fee_output(output: Option<&FundedOutput>, amount: u64) -> bool {
    match (output, amount) {
        (None, 0) => true,
        (Some(output), amount) if amount > 0 => {
            output.verify_public()
                && output.amount.commitment
                    == PedersenGens::default()
                        .commit(Scalar::from(amount), Scalar::ZERO)
                        .compress()
                        .to_bytes()
        }
        _ => false,
    }
}

fn take<const N: usize>(cursor: &mut Cursor<&[u8]>) -> Result<[u8; N], &'static str> {
    let mut bytes = [0; N];
    cursor
        .read_exact(&mut bytes)
        .map_err(|_| "truncated v3 block")?;
    Ok(bytes)
}

fn decode_optional_output(
    cursor: &mut Cursor<&[u8]>,
) -> Result<Option<FundedOutput>, &'static str> {
    match take::<1>(cursor)?[0] {
        0 => Ok(None),
        1 => {
            let len = u32::from_le_bytes(take(cursor)?) as usize;
            if len == 0 || len > 2048 {
                return Err("invalid fee output length");
            }
            let mut bytes = vec![0; len];
            cursor
                .read_exact(&mut bytes)
                .map_err(|_| "truncated fee output")?;
            Ok(Some(FundedOutput::decode_canonical(&bytes)?))
        }
        _ => Err("invalid fee output flag"),
    }
}

fn encode_optional_output(
    bytes: &mut Vec<u8>,
    output: Option<&FundedOutput>,
) -> Result<(), &'static str> {
    match output {
        None => bytes.push(0),
        Some(output) => {
            let encoded = output.encode_canonical();
            if encoded.len() > 2048 {
                return Err("oversized fee output");
            }
            bytes.push(1);
            bytes.extend_from_slice(&(encoded.len() as u32).to_le_bytes());
            bytes.extend_from_slice(&encoded);
        }
    }
    Ok(())
}

#[derive(Clone)]
pub struct BlockV3 {
    pub previous_hash: Hash,
    pub reward: Block,
    pub transactions: Vec<Transaction>,
    pub miner_fee_output: Option<FundedOutput>,
    pub treasury_fee_output: Option<FundedOutput>,
    pub difficulty_bits: u8,
    pub nonce: u64,
}

impl BlockV3 {
    pub fn decode(bytes: &[u8]) -> Result<Self, &'static str> {
        if bytes.len() > MAX_BLOCK_BYTES {
            return Err("oversized v3 block");
        }
        let mut cursor = Cursor::new(bytes);
        if &take::<10>(&mut cursor)? != TAG {
            return Err("wrong v3 block format");
        }
        let previous_hash = take(&mut cursor)?;
        let reward_len = u32::from_le_bytes(take(&mut cursor)?) as usize;
        if reward_len == 0 || reward_len > 2048 {
            return Err("invalid reward block length");
        }
        let mut reward_bytes = vec![0; reward_len];
        cursor
            .read_exact(&mut reward_bytes)
            .map_err(|_| "truncated v3 block")?;
        let reward = Block::decode(&reward_bytes)?;
        let count = if crate::network::IS_MAINNET {
            u16::from_le_bytes(take::<2>(&mut cursor)?) as usize
        } else { take::<1>(&mut cursor)?[0] as usize };
        if count > MAX_TXS {
            return Err("too many block transactions");
        }
        let mut transactions = Vec::with_capacity(count);
        for _ in 0..count {
            let len = u32::from_le_bytes(take(&mut cursor)?) as usize;
            if len == 0 || len > MAX_TX_BYTES {
                return Err("invalid block transaction length");
            }
            let mut encoded = vec![0; len];
            cursor
                .read_exact(&mut encoded)
                .map_err(|_| "truncated v3 block")?;
            transactions.push(Transaction::decode(&encoded)?);
        }
        let miner_fee_output = decode_optional_output(&mut cursor)?;
        let treasury_fee_output = decode_optional_output(&mut cursor)?;
        let difficulty_bits = take::<1>(&mut cursor)?[0];
        let nonce = u64::from_le_bytes(take(&mut cursor)?);
        if cursor.position() != bytes.len() as u64 {
            return Err("trailing v3 block bytes");
        }
        Ok(Self {
            previous_hash,
            reward,
            transactions,
            miner_fee_output,
            treasury_fee_output,
            difficulty_bits,
            nonce,
        })
    }

    pub fn encode(&self) -> Result<Vec<u8>, &'static str> {
        if self.transactions.len() > MAX_TXS {
            return Err("too many block transactions");
        }
        let reward = self.reward.encode();
        if reward.len() > 2048 {
            return Err("oversized reward block");
        }
        let mut bytes = Vec::new();
        bytes.extend_from_slice(TAG);
        bytes.extend_from_slice(&self.previous_hash);
        bytes.extend_from_slice(&(reward.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&reward);
        if crate::network::IS_MAINNET {
            bytes.extend_from_slice(&(self.transactions.len() as u16).to_le_bytes());
        } else { bytes.push(self.transactions.len() as u8); }
        for tx in &self.transactions {
            let encoded = tx.encode()?;
            if encoded.len() > MAX_TX_BYTES {
                return Err("oversized block transaction");
            }
            bytes.extend_from_slice(&(encoded.len() as u32).to_le_bytes());
            bytes.extend_from_slice(&encoded);
        }
        encode_optional_output(&mut bytes, self.miner_fee_output.as_ref())?;
        encode_optional_output(&mut bytes, self.treasury_fee_output.as_ref())?;
        bytes.push(self.difficulty_bits);
        bytes.extend_from_slice(&self.nonce.to_le_bytes());
        if bytes.len() > MAX_BLOCK_BYTES {
            return Err("oversized v3 block");
        }
        Ok(bytes)
    }

    pub fn hash(&self) -> Result<Hash, &'static str> {
        if crate::network::IS_MAINNET {
            return Ok(Self::mainnet_pow_hash(&self.mainnet_content_hash()?, self.nonce));
        }
        let mut hash = Sha256::new();
        hash.update(b"TSC-1:transaction-block:v3");
        hash.update(self.encode()?);
        Ok(hash.finalize().into())
    }

    fn mainnet_content_hash(&self) -> Result<Hash, &'static str> {
        let bytes = self.encode()?;
        Ok(Sha256::digest(&bytes[..bytes.len() - 8]).into())
    }

    fn mainnet_pow_hash(content: &Hash, nonce: u64) -> Hash {
        let mut hash = Sha256::new();
        hash.update(b"TENEBRA:mainnet:pow:v1");
        hash.update(crate::tsc1_tx_v2::NETWORK_ID);
        hash.update(content);
        hash.update(nonce.to_le_bytes());
        hash.finalize().into()
    }

    pub fn mine(&mut self) -> Result<(), &'static str> {
        if !(BASE_DIFFICULTY_BITS..=MAX_DIFFICULTY_BITS).contains(&self.difficulty_bits) {
            return Err("invalid v3 difficulty");
        }
        self.reward.mine()?;
        let content = if crate::network::IS_MAINNET { Some(self.mainnet_content_hash()?) } else { None };
        loop {
            let hash = match content {
                Some(ref content) => Self::mainnet_pow_hash(content, self.nonce),
                None => self.hash()?,
            };
            if hash_meets_difficulty(&hash, self.difficulty_bits) {
                return Ok(());
            }
            self.nonce = self.nonce.checked_add(1).ok_or("v3 nonce exhausted")?;
        }
    }
}

#[derive(Clone)]
pub struct ChainV3 {
    rewards: Chain,
    spends: SpendState,
    blocks: Vec<BlockV3>,
    tip_hash: Hash,
    cumulative_work: u128,
}

impl ChainV3 {
    pub fn from_genesis(genesis: Chain) -> Result<Self, &'static str> {
        if genesis.height() != 0 {
            return Err("v3 requires genesis-only anchor");
        }
        let mut hash = Sha256::new();
        hash.update(b"TSC-1:v3f-genesis-anchor");
        hash.update(genesis.genesis_hash());
        let tip_hash = hash.finalize().into();
        let spends =
            SpendState::from_reward_chain(&genesis).with_reward_maturity(REWARD_MATURITY_BLOCKS);
        Ok(Self {
            rewards: genesis,
            spends,
            blocks: Vec::new(),
            tip_hash,
            cumulative_work: 0,
        })
    }

    pub fn from_pinned_genesis() -> Result<Self, Box<dyn std::error::Error>> {
        Ok(Self::from_genesis(crate::network::pinned_genesis()?)?)
    }

    pub fn height(&self) -> u64 {
        self.rewards.height()
    }
    pub fn tip_hash(&self) -> Hash {
        self.tip_hash
    }
    pub fn cumulative_work(&self) -> u128 {
        self.cumulative_work
    }

    pub fn finalized_height(&self) -> u64 {
        // Public PoW confirmations are probabilistic, not an irreversible checkpoint.
        if crate::network::IS_MAINNET { 0 } else { self.height().saturating_sub(FINALITY_DEPTH) }
    }
    pub fn next_difficulty_bits(&self) -> u8 {
        let Some(last) = self.blocks.last() else {
            return BASE_DIFFICULTY_BITS;
        };
        let bits = last.difficulty_bits;
        if !self.blocks.len().is_multiple_of(RETARGET_WINDOW) {
            return bits;
        }
        let first = &self.blocks[self.blocks.len() - RETARGET_WINDOW];
        let elapsed = last.reward.timestamp.saturating_sub(first.reward.timestamp);
        let expected = (RETARGET_WINDOW as u64 - 1) * TARGET_BLOCK_SECONDS;
        if elapsed < expected / 2 {
            bits.saturating_add(1).min(MAX_DIFFICULTY_BITS)
        } else if elapsed > expected * 2 {
            bits.saturating_sub(1).max(BASE_DIFFICULTY_BITS)
        } else {
            bits
        }
    }
    pub fn rewards(&self) -> &Chain {
        &self.rewards
    }
    pub fn spends(&self) -> &SpendState {
        &self.spends
    }

    pub fn wallet_balance_nox(&self, wallet: &WalletSecrets) -> Result<u64, &'static str> {
        let mut balance = 0u64;
        let mut count_output = |output: &FundedOutput, index: u64| -> Result<(), &'static str> {
            if let Some(recovered) = wallet.scan_funded_output(output, index) {
                let secret =
                    Option::<Scalar>::from(Scalar::from_canonical_bytes(recovered.one_time_spend))
                        .ok_or("invalid recovered spend key")?;
                if !self.spends.has_spent_image(&key_image_for_secret(secret)) {
                    balance = balance
                        .checked_add(recovered.amount_nox)
                        .ok_or("wallet balance overflow")?;
                }
            }
            Ok(())
        };
        count_output(&self.rewards.genesis_block().reward_output, 0)?;
        for block in &self.blocks {
            count_output(&block.reward.reward_output, 0)?;
            if let Some(output) = &block.miner_fee_output {
                count_output(output, 0)?;
            }
            if let Some(output) = &block.treasury_fee_output {
                count_output(output, 0)?;
            }
            for tx in &block.transactions {
                for (index, output) in tx.outputs.iter().enumerate() {
                    count_output(output, index as u64)?;
                }
            }
        }
        Ok(balance)
    }
    pub fn blocks(&self) -> &[BlockV3] {
        &self.blocks
    }

    pub fn encode(&self) -> Result<Vec<u8>, &'static str> {
        if self.blocks.len() > u32::MAX as usize {
            return Err("too many v3 blocks");
        }
        let mut bytes = Vec::new();
        bytes.extend_from_slice(b"TSC1CHN3F1");
        bytes.extend_from_slice(&self.rewards.genesis_hash());
        bytes.extend_from_slice(&(self.blocks.len() as u32).to_le_bytes());
        for block in &self.blocks {
            let encoded = block.encode()?;
            bytes.extend_from_slice(&(encoded.len() as u32).to_le_bytes());
            bytes.extend_from_slice(&encoded);
        }
        Ok(bytes)
    }

    pub fn decode(bytes: &[u8], genesis: Chain) -> Result<Self, &'static str> {
        let mut cursor = Cursor::new(bytes);
        if &take::<10>(&mut cursor)? != b"TSC1CHN3F1" {
            return Err("wrong v3 chain format");
        }
        if take::<32>(&mut cursor)? != genesis.genesis_hash() {
            return Err("v3 genesis hash mismatch");
        }
        let count = u32::from_le_bytes(take(&mut cursor)?) as usize;
        if count > 1_000_000 {
            return Err("too many v3 blocks");
        }
        let mut chain = Self::from_genesis(genesis)?;
        for _ in 0..count {
            let len = u32::from_le_bytes(take(&mut cursor)?) as usize;
            if len == 0 || len > MAX_BLOCK_BYTES {
                return Err("invalid v3 block length");
            }
            let mut encoded = vec![0; len];
            cursor
                .read_exact(&mut encoded)
                .map_err(|_| "truncated v3 chain")?;
            chain.append(BlockV3::decode(&encoded)?)?;
        }
        if cursor.position() != bytes.len() as u64 {
            return Err("trailing v3 chain bytes");
        }
        Ok(chain)
    }

    pub fn next_block(
        &self,
        reward_output: FundedOutput,
        timestamp: u64,
        transactions: Vec<Transaction>,
    ) -> BlockV3 {
        BlockV3 {
            previous_hash: self.tip_hash,
            reward: self.rewards.next_block(reward_output, timestamp),
            transactions,
            miner_fee_output: None,
            treasury_fee_output: None,
            difficulty_bits: self.next_difficulty_bits(),
            nonce: 0,
        }
    }

    pub fn next_block_with_fees(
        &self,
        reward_output: FundedOutput,
        miner_fee_address: &Address,
        timestamp: u64,
        transactions: Vec<Transaction>,
    ) -> Result<BlockV3, &'static str> {
        let total = transactions.iter().try_fold(0u64, |sum, tx| {
            sum.checked_add(tx.fee_nox).ok_or("block fee overflow")
        })?;
        let (miner, treasury) = split_block_fees(total);
        let mut block = self.next_block(reward_output, timestamp, transactions);
        if miner > 0 {
            block.miner_fee_output = Some(create_reward_output(miner_fee_address, 0, miner)?);
        }
        if treasury > 0 {
            let address = Address::parse(TREASURY_ADDRESS)?;
            block.treasury_fee_output = Some(create_public_fee_output(
                &address,
                treasury,
                treasury_secret(block.previous_hash, block.reward.height),
            )?);
        }
        Ok(block)
    }

    pub fn append(&mut self, block: BlockV3) -> Result<(), &'static str> {
        if block.previous_hash != self.tip_hash {
            return Err("invalid v3 block link");
        }
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|_| "system clock before unix epoch")?
            .as_secs();
        if block.reward.timestamp > now.saturating_add(MAX_FUTURE_DRIFT_SECONDS) {
            return Err("v3 block timestamp too far in future");
        }
        if block.difficulty_bits != self.next_difficulty_bits() {
            return Err("wrong v3 difficulty");
        }
        let hash = block.hash()?;
        if !hash_meets_difficulty(&hash, block.difficulty_bits) {
            return Err("insufficient v3 proof of work");
        }
        let cumulative_work = self
            .cumulative_work
            .checked_add(1u128 << block.difficulty_bits)
            .ok_or("v3 cumulative work overflow")?;
        let total_fee = block.transactions.iter().try_fold(0u64, |sum, tx| {
            sum.checked_add(tx.fee_nox).ok_or("block fee overflow")
        })?;
        let (miner_fee, treasury_fee) = split_block_fees(total_fee);
        if !valid_fee_output(block.miner_fee_output.as_ref(), miner_fee)
            || !valid_fee_output(block.treasury_fee_output.as_ref(), treasury_fee)
        {
            return Err("invalid fee payout amount");
        }
        if let Some(output) = &block.treasury_fee_output {
            let address = Address::parse(TREASURY_ADDRESS)?;
            let expected = output_from_ephemeral_secret(
                &address,
                0,
                treasury_secret(block.previous_hash, block.reward.height),
            )?;
            if output.destination != expected {
                return Err("wrong treasury destination");
            }
        }
        let mut rewards = self.rewards.clone();
        rewards.append(block.reward.clone())?;
        let mut spends = self.spends.clone();
        spends.apply_batch(&block.transactions, block.reward.height)?;
        spends.add_mining_reward(
            block.reward.reward_output_id(),
            &block.reward.reward_output,
            block.reward.height,
        )?;
        if let Some(output) = &block.miner_fee_output {
            spends.add_reward_output(fee_output_id(hash, 0), output)?;
        }
        if let Some(output) = &block.treasury_fee_output {
            spends.add_reward_output(fee_output_id(hash, 1), output)?;
        }
        self.rewards = rewards;
        self.spends = spends;
        self.tip_hash = hash;
        self.cumulative_work = cumulative_work;
        self.blocks.push(block);
        Ok(())
    }
}

pub fn load_blocks(
    directory: &Path,
    genesis: Chain,
) -> Result<ChainV3, Box<dyn std::error::Error>> {
    let mut chain = ChainV3::from_genesis(genesis)?;
    if !directory.exists() {
        return Ok(chain);
    }
    let mut files = Vec::new();
    for entry in fs::read_dir(directory)? {
        let path = entry?.path();
        if path.extension().is_some_and(|ext| ext == "bin") {
            let height: u64 = path
                .file_stem()
                .ok_or("invalid v3 block filename")?
                .to_str()
                .ok_or("invalid v3 block filename")?
                .parse()?;
            files.push((height, path));
        }
    }
    files.sort_by_key(|(height, _)| *height);
    for (height, path) in files {
        if height != chain.height() + 1 {
            return Err("missing or duplicate v3 block".into());
        }
        if fs::metadata(&path)?.len() > MAX_BLOCK_BYTES as u64 {
            return Err("oversized v3 block".into());
        }
        chain.append(BlockV3::decode(&fs::read(path)?)?)?;
    }
    Ok(chain)
}

pub fn persist_block(directory: &Path, block: &BlockV3) -> Result<(), Box<dyn std::error::Error>> {
    let encoded = block.encode()?;
    fs::create_dir_all(directory)?;
    let target = directory.join(format!("{:020}.bin", block.reward.height));
    if target.exists() {
        return Err("v3 block already persisted".into());
    }
    let mut suffix = [0u8; 8];
    getrandom::getrandom(&mut suffix)?;
    let temporary = directory.join(format!(
        "{:020}.{}.tmp",
        block.reward.height,
        hex::encode(suffix)
    ));
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&temporary)?;
    file.write_all(&encoded)?;
    file.sync_all()?;
    drop(file);
    fs::rename(temporary, target)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::FOUNDER_ALLOCATION_NOX;
    use crate::WalletSecrets;
    use crate::tsc1_chain_v2::reward_at_height;
    use crate::tsc1_funded_output::create_reward_output;

    #[test]
    fn v3_block_round_trip_and_link_validation() {
        let founder = WalletSecrets::from_seed(&[81; 32]);
        let genesis_output =
            create_reward_output(&founder.address(), 0, FOUNDER_ALLOCATION_NOX).unwrap();
        let genesis = Chain::new(genesis_output, 1).unwrap();
        let genesis_for_decode = genesis.clone();
        let mut chain = ChainV3::from_genesis(genesis).unwrap();
        let miner = WalletSecrets::from_seed(&[82; 32]);
        let reward = create_reward_output(&miner.address(), 0, reward_at_height(1)).unwrap();
        let mut block = chain.next_block(reward, 2, Vec::new());
        block.mine().unwrap();
        let encoded = block.encode().unwrap();
        let decoded = BlockV3::decode(&encoded).unwrap();
        assert_eq!(decoded.hash().unwrap(), block.hash().unwrap());
        assert!(BlockV3::decode(&encoded[..encoded.len() - 1]).is_err());
        let mut trailing = encoded.clone();
        trailing.push(0);
        assert!(BlockV3::decode(&trailing).is_err());
        let mut wrong_link = block.clone();
        wrong_link.previous_hash[0] ^= 1;
        wrong_link.mine().unwrap();
        assert!(chain.append(wrong_link).is_err());
        assert_eq!(chain.height(), 0);
        let mut wrong_difficulty = block.clone();
        wrong_difficulty.difficulty_bits += 1;
        wrong_difficulty.mine().unwrap();
        assert_eq!(chain.append(wrong_difficulty), Err("wrong v3 difficulty"));
        chain.append(decoded.clone()).unwrap();
        assert_eq!(chain.height(), 1);
        assert_eq!(chain.cumulative_work(), 1u128 << BASE_DIFFICULTY_BITS);
        let mut suffix = [0u8; 8];
        getrandom::getrandom(&mut suffix).unwrap();
        let directory =
            std::env::temp_dir().join(format!("tsc1-v3-block-test-{}", hex::encode(suffix)));
        persist_block(&directory, &decoded).unwrap();
        let restored_files = load_blocks(&directory, genesis_for_decode.clone()).unwrap();
        assert_eq!(restored_files.tip_hash(), chain.tip_hash());
        let file = directory.join("00000000000000000001.bin");
        let mut damaged = fs::read(&file).unwrap();
        damaged[0] ^= 1;
        fs::write(&file, damaged).unwrap();
        assert!(load_blocks(&directory, genesis_for_decode.clone()).is_err());
        fs::remove_file(file).unwrap();
        fs::remove_dir(directory).unwrap();
        let encoded_chain = chain.encode().unwrap();
        let restored = ChainV3::decode(&encoded_chain, genesis_for_decode.clone()).unwrap();
        assert_eq!(restored.tip_hash(), chain.tip_hash());
        assert!(
            ChainV3::decode(
                &encoded_chain[..encoded_chain.len() - 1],
                genesis_for_decode.clone()
            )
            .is_err()
        );
        let mut trailing_chain = encoded_chain;
        trailing_chain.push(0);
        assert!(ChainV3::decode(&trailing_chain, genesis_for_decode).is_err());
    }

    #[test]
    fn rejects_mined_block_too_far_in_future() {
        let founder = WalletSecrets::from_seed(&[83; 32]);
        let genesis = Chain::new(
            create_reward_output(&founder.address(), 0, FOUNDER_ALLOCATION_NOX).unwrap(),
            1,
        )
        .unwrap();
        let mut chain = ChainV3::from_genesis(genesis).unwrap();
        let miner = WalletSecrets::from_seed(&[84; 32]);
        let reward = create_reward_output(&miner.address(), 0, reward_at_height(1)).unwrap();
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        let mut block = chain.next_block(reward, now + MAX_FUTURE_DRIFT_SECONDS + 60, Vec::new());
        block.mine().unwrap();
        assert_eq!(
            chain.append(block),
            Err("v3 block timestamp too far in future")
        );
        assert_eq!(chain.height(), 0);
    }
}
